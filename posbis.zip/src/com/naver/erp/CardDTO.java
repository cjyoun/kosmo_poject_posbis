package com.naver.erp;

public class CardDTO {

	private int u_no;
	private String creditNum1;
	private String creditNum2;
	private String creditNum3;
	private String creditNum4;
	private String credit_no;
	
	private String ex_month;
	private String ex_year;
	private String cvc_no;
	
	private String jumin_no;
	private String credit_pwd;
	public int getU_no() {
		return u_no;
	}
	public void setU_no(int u_no) {
		this.u_no = u_no;
	}
	public String getCreditNum1() {
		return creditNum1;
	}
	public void setCreditNum1(String creditNum1) {
		this.creditNum1 = creditNum1;
	}
	public String getCreditNum2() {
		return creditNum2;
	}
	public void setCreditNum2(String creditNum2) {
		this.creditNum2 = creditNum2;
	}
	public String getCreditNum3() {
		return creditNum3;
	}
	public void setCreditNum3(String creditNum3) {
		this.creditNum3 = creditNum3;
	}
	public String getCreditNum4() {
		return creditNum4;
	}
	public void setCreditNum4(String creditNum4) {
		this.creditNum4 = creditNum4;
	}
	public String getCredit_no() {
		return credit_no;
	}
	public void setCredit_no(String credit_no) {
		this.credit_no = credit_no;
	}
	public String getEx_month() {
		return ex_month;
	}
	public void setEx_month(String ex_month) {
		this.ex_month = ex_month;
	}
	public String getEx_year() {
		return ex_year;
	}
	public void setEx_year(String ex_year) {
		this.ex_year = ex_year;
	}
	public String getCvc_no() {
		return cvc_no;
	}
	public void setCvc_no(String cvc_no) {
		this.cvc_no = cvc_no;
	}
	public String getJumin_no() {
		return jumin_no;
	}
	public void setJumin_no(String jumin_no) {
		this.jumin_no = jumin_no;
	}
	public String getCredit_pwd() {
		return credit_pwd;
	}
	public void setCredit_pwd(String credit_pwd) {
		this.credit_pwd = credit_pwd;
	}
	
	
	
	
	

	
	
}
