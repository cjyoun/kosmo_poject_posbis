package com.naver.erp;

import java.util.List;
import java.util.Map;

public class AllBusinessNoDTO {

	private String[] allBusinessNo;

	public String[] getAllBusinessNo() {
		return allBusinessNo;
	}

	public void setAllBusinessNo(String[] allBusinessNo) {
		this.allBusinessNo = allBusinessNo;
	}
	

	
	
}
