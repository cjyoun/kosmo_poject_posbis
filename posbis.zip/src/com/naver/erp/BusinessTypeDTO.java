package com.naver.erp;

public class BusinessTypeDTO {
	
	private String business_type_code;
	private String business_type_code1;
	private String business_type_name1;
	private String business_type_code2;
	private String business_type_name2;
	
	
	public String getBusiness_type_code() {
		return business_type_code;
	}
	public void setBusiness_type_code(String business_type_code) {
		this.business_type_code = business_type_code;
	}
	public String getBusiness_type_code1() {
		return business_type_code1;
	}
	public void setBusiness_type_code1(String business_type_code1) {
		this.business_type_code1 = business_type_code1;
	}
	public String getBusiness_type_name1() {
		return business_type_name1;
	}
	public void setBusiness_type_name1(String business_type_name1) {
		this.business_type_name1 = business_type_name1;
	}
	public String getBusiness_type_code2() {
		return business_type_code2;
	}
	public void setBusiness_type_code2(String business_type_code2) {
		this.business_type_code2 = business_type_code2;
	}
	public String getBusiness_type_name2() {
		return business_type_name2;
	}
	public void setBusiness_type_name2(String business_type_name2) {
		this.business_type_name2 = business_type_name2;
	}
	
	
	

}
