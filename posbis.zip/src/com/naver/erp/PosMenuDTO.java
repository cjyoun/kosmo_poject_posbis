package com.naver.erp;

public class PosMenuDTO {


	private String business_no;
	private String menu_name;
	
	
	public String getBusiness_no() {
		return business_no;
	}
	public void setBusiness_no(String business_no) {
		this.business_no = business_no;
	}
	public String getMenu_name() {
		return menu_name;
	}
	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}

	
 
	
 
	
	
	
}
