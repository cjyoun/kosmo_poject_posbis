package com.naver.erp;

import java.util.List;
import java.util.Map;

public class MyPageDTO {
	
	
	private List<Map<String, String>> myInfo;
	

	public List<Map<String, String>> getMyInfo() {
		return myInfo;
	}

	public void setMyInfo(List<Map<String, String>> myInfo) {
		this.myInfo = myInfo;
	}
	
	
	

}
