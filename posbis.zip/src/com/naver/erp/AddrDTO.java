package com.naver.erp;

public class AddrDTO {

	private String addr_no;
	private String addr_gu_no;
	private String addr_gu;
	private String addr_dong_no;
	private String addr_dong;
	
	public String getAddr_no() {
		return addr_no;
	}
	public void setAddr_no(String addr_no) {
		this.addr_no = addr_no;
	}
	public String getAddr_gu_no() {
		return addr_gu_no;
	}
	public void setAddr_gu_no(String addr_gu_no) {
		this.addr_gu_no = addr_gu_no;
	}
	public String getAddr_gu() {
		return addr_gu;
	}
	public void setAddr_gu(String addr_gu) {
		this.addr_gu = addr_gu;
	}
	public String getAddr_dong_no() {
		return addr_dong_no;
	}
	public void setAddr_dong_no(String addr_dong_no) {
		this.addr_dong_no = addr_dong_no;
	}
	public String getAddr_dong() {
		return addr_dong;
	}
	public void setAddr_dong(String addr_dong) {
		this.addr_dong = addr_dong;
	}
	
	
	
}
